# CHEME-5440-7770-PS2-S21
This repository holds the code for Problem Set 2. You can download this repository as either a ``zip`` file (click the green code button on the upper right) or use the ``clone`` command from the command line:

    $ git clone https://github.com/varnerlab/CHEME-5440-7770-PS2-S21.git

